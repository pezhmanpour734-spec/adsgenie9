def test_instance_isolation():
    assert "instance_id" in ["instance_id"]
def test_policy():
    assert 25 == 25
    assert 60 == 60
    assert 3600 == 3600
